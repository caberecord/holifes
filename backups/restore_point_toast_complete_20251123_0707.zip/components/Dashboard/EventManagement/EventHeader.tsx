"use client";
import { Eye, ExternalLink } from "lucide-react";
import { Event } from "../../../types/event";

interface EventHeaderProps {
    event: Event;
}

export default function EventHeader({ event }: EventHeaderProps) {
    return (
        <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <div>
                <h1 className="text-2xl font-bold text-gray-900">{event.name}</h1>
                <div className="flex items-center gap-2 mt-1">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${event.status === 'published' ? 'bg-green-100 text-green-800' :
                            event.status === 'draft' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                        {event.status === 'published' ? 'Publicado' : event.status === 'draft' ? 'En Construcción' : event.status}
                    </span>
                    <span className="text-sm text-gray-500 flex items-center">
                        ID: {event.id}
                    </span>
                </div>
            </div>
            <div className="flex gap-3">
                <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                    <Eye className="w-4 h-4 mr-2" />
                    Previsualizar
                </button>
                <button className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Publicar Evento
                </button>
            </div>
        </div>
    );
}
