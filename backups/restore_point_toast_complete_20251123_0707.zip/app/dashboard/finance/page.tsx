import FinanceModule from "@/components/Dashboard/Finance/FinanceModule";

export default function FinancePage() {
    return <FinanceModule />;
}
