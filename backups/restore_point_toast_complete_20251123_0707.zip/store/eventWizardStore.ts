import { create } from 'zustand';

export type EventPlan = 'freemium-a' | 'freemium-b' | 'pro' | 'enterprise';
export type VenueType = 'auditorium' | 'concert-hall' | 'open-field' | 'theater';
export type DistributionMethod = 'manual' | 'stripe' | 'invite';

export interface TicketZone {
    id: string;
    name: string;
    capacity: number;
    price: number;
    color: string;
    x: number;
    y: number;
    width: number;
    height: number;
    type: 'standing' | 'seating';
    shape: 'rectangle' | 'L' | 'T';
    rotation: number;
}

export interface WizardState {
    currentStep: number;
    // Step 1: Basic Info
    basicInfo: {
        name: string;
        date: string;
        startTime: string;
        endTime: string;
        location: string;
        googleMapsUrl?: string;
        category: string;
        description: string;
    };
    // Step 2: Plan
    selectedPlan: EventPlan | null;
    // Step 3: Venue
    venue: {
        type: VenueType | null;
        zones: TicketZone[];
        totalCapacity: number;
    };
    // Step 4: Distribution
    distribution: {
        method: DistributionMethod | null;
        uploadedGuests: any[]; // Array from Excel
    };

    // Actions
    setStep: (step: number) => void;
    updateBasicInfo: (info: Partial<WizardState['basicInfo']>) => void;
    setPlan: (plan: EventPlan) => void;
    setVenueType: (type: VenueType) => void;
    updateZones: (zones: TicketZone[]) => void;
    updateZonePosition: (id: string, x: number, y: number) => void;
    setDistributionMethod: (method: DistributionMethod) => void;
    setUploadedGuests: (guests: any[]) => void;
    resetWizard: () => void;
}

export const useEventWizardStore = create<WizardState>((set) => ({
    currentStep: 1,
    basicInfo: {
        name: '',
        date: '',
        startTime: '',
        endTime: '',
        location: '',
        googleMapsUrl: '',
        category: '',
        description: '',
    },
    selectedPlan: null,
    venue: {
        type: null,
        zones: [],
        totalCapacity: 0,
    },
    distribution: {
        method: null,
        uploadedGuests: [],
    },

    setStep: (step) => set({ currentStep: step }),
    updateBasicInfo: (info) =>
        set((state) => ({ basicInfo: { ...state.basicInfo, ...info } })),
    setPlan: (plan) => set({ selectedPlan: plan }),
    setVenueType: (type) =>
        set((state) => ({ venue: { ...state.venue, type } })),
    updateZones: (zones) =>
        set((state) => ({
            venue: {
                ...state.venue,
                zones,
                totalCapacity: zones.reduce((acc, zone) => acc + zone.capacity, 0),
            },
        })),
    updateZonePosition: (id, x, y) =>
        set((state) => ({
            venue: {
                ...state.venue,
                zones: state.venue.zones.map((z) => (z.id === id ? { ...z, x, y } : z)),
            },
        })),
    setDistributionMethod: (method) =>
        set((state) => ({ distribution: { ...state.distribution, method } })),
    setUploadedGuests: (guests) =>
        set((state) => ({ distribution: { ...state.distribution, uploadedGuests: guests } })),
    resetWizard: () =>
        set({
            currentStep: 1,
            basicInfo: {
                name: '',
                date: '',
                startTime: '',
                endTime: '',
                location: '',
                googleMapsUrl: '',
                category: '',
                description: '',
            },
            selectedPlan: null,
            venue: { type: null, zones: [], totalCapacity: 0 },
            distribution: { method: null, uploadedGuests: [] },
        }),
}));
