import { getResendClient, APP_URL, FROM_EMAIL } from './resend';
import { Event } from '../../types/event';

interface SendEventConfirmationParams {
    email: string;
    userName: string;
    event: Event;
}

export async function sendEventConfirmationEmail({
    email,
    userName,
    event,
}: SendEventConfirmationParams): Promise<void> {
    try {
        const eventDate = new Date(event.startDate).toLocaleDateString('es-ES', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });

        const eventTime = new Date(event.startDate).toLocaleTimeString('es-ES', {
            hour: '2-digit',
            minute: '2-digit',
        });

        const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body {
              font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 600px;
              margin: 0 auto;
              padding: 0;
              background-color: #f4f4f5;
            }
            .container {
              background-color: #ffffff;
              border-radius: 12px;
              overflow: hidden;
              margin: 20px;
              box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            }
            .header {
              background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
              color: white;
              padding: 40px 20px;
              text-align: center;
            }
            .header h1 {
              margin: 0;
              font-size: 24px;
              font-weight: 700;
            }
            .content {
              padding: 40px 30px;
            }
            .event-card {
              background-color: #f8fafc;
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              padding: 20px;
              margin: 20px 0;
            }
            .event-title {
              font-size: 18px;
              font-weight: 700;
              color: #1e293b;
              margin-bottom: 10px;
            }
            .event-detail {
              display: flex;
              align-items: center;
              margin-bottom: 8px;
              color: #64748b;
              font-size: 14px;
            }
            .button {
              display: block;
              width: 100%;
              background: #4f46e5;
              color: white;
              padding: 14px 0;
              text-align: center;
              text-decoration: none;
              border-radius: 6px;
              font-weight: 600;
              margin-top: 30px;
            }
            .footer {
              text-align: center;
              padding: 20px;
              color: #94a3b8;
              font-size: 12px;
              background-color: #f8fafc;
              border-top: 1px solid #e2e8f0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>¡Evento Creado Exitosamente! 🎉</h1>
            </div>
            
            <div class="content">
              <p>Hola <strong>${userName}</strong>,</p>
              <p>Tu evento ha sido publicado y está listo para recibir asistentes. Aquí tienes los detalles principales:</p>
              
              <div class="event-card">
                <div class="event-title">${event.name || event.title}</div>
                <div class="event-detail">📅 ${eventDate}</div>
                <div class="event-detail">⏰ ${eventTime}</div>
                <div class="event-detail">📍 ${event.location?.address || 'Ubicación por definir'}</div>
              </div>
              
              <p>Ahora puedes empezar a gestionar tus tickets, invitar a tu staff y promocionar tu evento.</p>
              
              <a href="${APP_URL}/dashboard/events" class="button">
                Gestionar mi Evento
              </a>
            </div>
            
            <div class="footer">
              <p>Enviado a través de Holifes</p>
              <p>© ${new Date().getFullYear()} Holifes. Todos los derechos reservados.</p>
            </div>
          </div>
        </body>
      </html>
    `;

        const resend = getResendClient();
        const senderEmail = process.env.RESEND_FROM_EMAIL || FROM_EMAIL;

        console.log(`📧 Sending confirmation from: ${senderEmail}`);

        const { data, error } = await resend.emails.send({
            from: senderEmail,
            to: email,
            subject: `✅ Evento Creado: ${event.name || event.title}`,
            html: htmlContent,
        });

        if (error) {
            console.error('❌ Resend API Error:', error);
            throw new Error(`Resend API Error: ${error.message}`);
        }

        console.log(`✅ Event confirmation sent to: ${email}`, data);
    } catch (error) {
        console.error('Error sending event confirmation email:', error);
        throw error;
    }
}
