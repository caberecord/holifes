import CreateEventWizard from "@/components/Dashboard/Wizard/CreateEventWizard";

export default function CreateEventPage() {
    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Crear Nuevo Evento</h1>
                    <p className="text-gray-500">Configura tu evento en 4 sencillos pasos</p>
                </div>
            </div>

            <CreateEventWizard />
        </div>
    );
}
