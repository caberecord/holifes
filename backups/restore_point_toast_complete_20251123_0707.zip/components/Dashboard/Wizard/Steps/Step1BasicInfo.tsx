"use client";
import { useEventWizardStore } from "@/store/eventWizardStore";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { showToast } from "@/lib/toast";

const schema = z.object({
    name: z.string().min(3, "El nombre debe tener al menos 3 caracteres"),
    date: z.string().min(1, "La fecha es requerida"),
    startTime: z.string().min(1, "La hora de inicio es requerida"),
    endTime: z.string().min(1, "La hora de fin es requerida"),
    location: z.string().min(3, "La ubicación es requerida"),
    googleMapsUrl: z.string().optional(),
    category: z.string().min(1, "Selecciona una categoría"),
    description: z.string().max(500, "Máximo 500 caracteres"),
});

type FormData = z.infer<typeof schema>;

export default function Step1BasicInfo() {
    const { basicInfo, updateBasicInfo, setStep } = useEventWizardStore();

    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
    } = useForm<FormData>({
        resolver: zodResolver(schema),
        defaultValues: basicInfo,
    });

    const onSubmit = (data: FormData) => {
        updateBasicInfo(data);
        setStep(2);
    };

    return (
        <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Datos Básicos del Evento</h2>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Nombre del Evento
                    </label>
                    <input
                        {...register("name")}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="Ej: Concierto de Verano 2025"
                    />
                    {errors.name && (
                        <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
                    )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Fecha
                        </label>
                        <input
                            type="date"
                            {...register("date")}
                            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                        {errors.date && (
                            <p className="mt-1 text-sm text-red-600">{errors.date.message}</p>
                        )}
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Hora Inicio
                        </label>
                        <input
                            type="time"
                            {...register("startTime")}
                            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                        {errors.startTime && (
                            <p className="mt-1 text-sm text-red-600">{errors.startTime.message}</p>
                        )}
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Hora Fin
                        </label>
                        <input
                            type="time"
                            {...register("endTime")}
                            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        />
                        {errors.endTime && (
                            <p className="mt-1 text-sm text-red-600">{errors.endTime.message}</p>
                        )}
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Ubicación / Lugar
                    </label>
                    <input
                        {...register("location")}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="Ej: Teatro Nacional"
                    />
                    {errors.location && (
                        <p className="mt-1 text-sm text-red-600">{errors.location.message}</p>
                    )}
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Enlace de Google Maps (Opcional)
                    </label>
                    <div className="flex gap-2">
                        <input
                            {...register("googleMapsUrl")}
                            className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                            placeholder="https://maps.google.com/..."
                        />
                        <button
                            type="button"
                            onClick={() => {
                                const location = watch("location");
                                if (location) {
                                    window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`, '_blank');
                                } else {
                                    showToast.error("Por favor ingresa una ubicación primero");
                                }
                            }}
                            className="px-3 py-2 bg-indigo-50 text-indigo-600 rounded-lg border border-indigo-200 hover:bg-indigo-100 text-sm font-medium transition-colors"
                        >
                            📍 Buscar en Mapa
                        </button>
                        {watch("googleMapsUrl") && (
                            <a
                                href={watch("googleMapsUrl")}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-3 py-2 bg-gray-100 text-gray-600 rounded-lg border border-gray-300 hover:bg-gray-200 text-sm flex items-center"
                            >
                                🔗 Ver
                            </a>
                        )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                        Tip: Haz clic en "Buscar en Mapa" para encontrar tu ubicación, luego copia el enlace y pégalo aquí.
                    </p>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Categoría
                    </label>
                    <select
                        {...register("category")}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    >
                        <option value="">Selecciona una categoría</option>
                        <option value="concierto">Concierto</option>
                        <option value="teatro">Teatro</option>
                        <option value="conferencia">Conferencia</option>
                        <option value="deportes">Deportes</option>
                        <option value="otro">Otro</option>
                    </select>
                    {errors.category && (
                        <p className="mt-1 text-sm text-red-600">{errors.category.message}</p>
                    )}
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Descripción
                    </label>
                    <textarea
                        {...register("description")}
                        rows={4}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                        placeholder="Describe tu evento..."
                    />
                    {errors.description && (
                        <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
                    )}
                </div>

                <div className="flex justify-end pt-4">
                    <button
                        type="submit"
                        className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors font-medium"
                    >
                        Continuar
                    </button>
                </div>
            </form>
        </div>
    );
}
