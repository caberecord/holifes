"use client";
import { Event } from "../../../types/event";
import { useState } from "react";
import { Save, MapPin, Calendar, Type, Ticket, Loader2 } from "lucide-react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../../../lib/firebase";
import VenueDesignerComponent from "../VenueDesigner";

interface TabConfigProps {
    event: Event;
}

export default function TabConfig({ event }: TabConfigProps) {
    const [activeSection, setActiveSection] = useState("basic");
    const [formData, setFormData] = useState(event);
    const [isSaving, setIsSaving] = useState(false);
    // State for venue design editing
    const [venueData, setVenueData] = useState(event.venue || { type: null, zones: [], totalCapacity: 0 });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleVenueChange = (newVenue: any) => {
        setVenueData(newVenue);
    };

    const handleSave = async () => {
        if (!event.id) return;
        setIsSaving(true);
        try {
            const eventRef = doc(db, "events", event.id);
            await updateDoc(eventRef, {
                name: formData.name || "",
                date: formData.date || "",
                startTime: formData.startTime || "",
                endTime: formData.endTime || "",
                location: formData.location || "",
                googleMapsUrl: formData.googleMapsUrl || "",
                description: formData.description || "",
                venue: venueData, // Save the updated venue data
            });
            alert("Cambios guardados correctamente");
        } catch (error) {
            console.error("Error updating event:", error);
            alert("Error al guardar los cambios");
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="flex flex-col lg:flex-row min-h-[600px]">
            {/* Sidebar Navigation */}
            <div className="w-full lg:w-64 bg-white border-r border-gray-200 p-4 space-y-1">
                <button
                    onClick={() => setActiveSection("basic")}
                    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${activeSection === "basic" ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-50"}`}
                >
                    <Type className="w-4 h-4 mr-3" />
                    Información Básica
                </button>
                <button
                    onClick={() => setActiveSection("tickets")}
                    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${activeSection === "tickets" ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-50"}`}
                >
                    <Ticket className="w-4 h-4 mr-3" />
                    Entradas y Zonas
                </button>
                <button
                    onClick={() => setActiveSection("design")}
                    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${activeSection === "design" ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-50"}`}
                >
                    <MapPin className="w-4 h-4 mr-3" />
                    Diseño
                </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 p-6 bg-gray-50">
                {activeSection === "basic" && (
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 max-w-3xl">
                        <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
                            <Type className="w-5 h-5 mr-2 text-indigo-600" />
                            Información Básica
                        </h3>

                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Nombre del Evento</label>
                                <input
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                    className="w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
                                    <div className="relative">
                                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                        <input
                                            type="date"
                                            name="date"
                                            value={formData.date}
                                            onChange={handleChange}
                                            className="w-full pl-10 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Hora Inicio</label>
                                    <input
                                        type="time"
                                        name="startTime"
                                        value={formData.startTime || ""}
                                        onChange={handleChange}
                                        className="w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Hora Fin</label>
                                    <input
                                        type="time"
                                        name="endTime"
                                        value={formData.endTime || ""}
                                        onChange={handleChange}
                                        className="w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Ubicación</label>
                                <div className="relative">
                                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                    <input
                                        type="text"
                                        name="location"
                                        value={formData.location}
                                        onChange={handleChange}
                                        className="w-full pl-10 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Enlace de Google Maps</label>
                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        name="googleMapsUrl"
                                        value={formData.googleMapsUrl || ""}
                                        onChange={handleChange}
                                        placeholder="https://maps.google.com/..."
                                        className="flex-1 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                    />
                                    <button
                                        onClick={() => {
                                            if (formData.location) {
                                                window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(formData.location)}`, '_blank');
                                            } else {
                                                alert("Por favor ingresa una ubicación primero");
                                            }
                                        }}
                                        className="px-3 py-2 bg-indigo-50 text-indigo-600 rounded-lg border border-indigo-200 hover:bg-indigo-100 text-sm font-medium transition-colors"
                                    >
                                        📍 Buscar
                                    </button>
                                    <a
                                        href={formData.googleMapsUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className={`px-3 py-2 rounded-lg border border-gray-300 text-sm flex items-center justify-center ${formData.googleMapsUrl ? 'bg-white text-indigo-600 hover:bg-gray-50' : 'bg-gray-100 text-gray-400 pointer-events-none'}`}
                                    >
                                        <MapPin className="w-4 h-4" />
                                    </a>
                                </div>
                                <p className="text-xs text-gray-500 mt-1">
                                    Tip: Usa el botón "Buscar" para encontrar la ubicación en Google Maps y copia el enlace aquí.
                                </p>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
                                <textarea
                                    name="description"
                                    value={formData.description}
                                    onChange={handleChange}
                                    rows={4}
                                    className="w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                />
                            </div>

                            <div className="pt-4 border-t border-gray-100 flex justify-end">
                                <button
                                    onClick={handleSave}
                                    disabled={isSaving}
                                    className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50"
                                >
                                    {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                                    {isSaving ? "Guardando..." : "Guardar Cambios"}
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {activeSection === "tickets" && (
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 max-w-3xl">
                        <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
                            <Ticket className="w-5 h-5 mr-2 text-indigo-600" />
                            Gestión de Entradas y Zonas
                        </h3>

                        <div className="space-y-4">
                            {venueData.zones?.map((zone: any, idx: number) => (
                                <div key={idx} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-indigo-300 transition-colors">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold">
                                            {zone.name.charAt(0)}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-gray-900">{zone.name}</h4>
                                            <p className="text-sm text-gray-500">{zone.capacity} entradas • ${zone.price}</p>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => setActiveSection("design")}
                                        className="text-sm text-indigo-600 font-medium hover:underline"
                                    >
                                        Editar en Diseño
                                    </button>
                                </div>
                            ))}

                            <button
                                onClick={() => setActiveSection("design")}
                                className="w-full py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 font-medium hover:border-indigo-500 hover:text-indigo-600 transition-colors"
                            >
                                + Gestionar Zonas en Diseño
                            </button>
                        </div>
                    </div>
                )}

                {activeSection === "design" && (
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-lg font-bold text-gray-900 flex items-center">
                                <MapPin className="w-5 h-5 mr-2 text-indigo-600" />
                                Diseño del Recinto
                            </h3>
                            <button
                                onClick={handleSave}
                                disabled={isSaving}
                                className="flex items-center px-3 py-1.5 bg-indigo-600 text-white text-sm rounded-lg font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50"
                            >
                                {isSaving ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Save className="w-3 h-3 mr-1" />}
                                Guardar Diseño
                            </button>
                        </div>

                        <div className="border border-gray-200 rounded-lg overflow-hidden">
                            <VenueDesignerComponent venue={venueData as any} onChange={handleVenueChange} />
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
