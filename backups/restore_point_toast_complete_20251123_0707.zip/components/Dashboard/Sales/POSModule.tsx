"use client";
import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs, doc, updateDoc, arrayUnion } from "firebase/firestore";
import { Event } from "@/types/event";
import { Ticket, Users, CreditCard, CheckCircle, Search, Calendar, MapPin, Mail, User, Phone, CreditCard as IdCard } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { generateSecureTicketId } from "@/lib/ticketSecurity";

export default function POSModule() {
    const { user } = useAuth();
    const [events, setEvents] = useState<Event[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
    const [step, setStep] = useState<1 | 2 | 3>(1); // 1: Event/Tickets, 2: Attendees, 3: Payment/Confirm

    // Ticket Selection State
    const [selectedZone, setSelectedZone] = useState<string>("");
    const [ticketQuantity, setTicketQuantity] = useState<number>(1);

    // Attendee Data State
    const [sameInfo, setSameInfo] = useState(true);
    const [mainAttendee, setMainAttendee] = useState({ name: "", email: "", phone: "", idNumber: "" });
    const [attendeesList, setAttendeesList] = useState<any[]>([]);

    // Payment State
    const [paymentMethod, setPaymentMethod] = useState("efectivo");
    const [isProcessing, setIsProcessing] = useState(false);

    useEffect(() => {
        const fetchEvents = async () => {
            try {
                // Fetch only published events
                // In a real app, you might want to filter by date too (future events)
                const q = query(collection(db, "events"), where("status", "==", "draft")); // Using draft for testing, change to published later if needed
                // OR fetch all and filter client side if status isn't reliable yet
                // const q = query(collection(db, "events")); 

                const querySnapshot = await getDocs(q);
                const eventsData = querySnapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                })) as Event[];

                // Filter for active events (optional additional filtering)
                setEvents(eventsData);
            } catch (error) {
                console.error("Error fetching events:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchEvents();
    }, []);

    const handleEventSelect = (event: Event) => {
        setSelectedEvent(event);
        setSelectedZone(event.venue?.zones[0]?.name || "");
        setStep(1);
    };

    const handleContinueToAttendees = () => {
        if (!selectedZone) {
            alert("Selecciona una zona");
            return;
        }

        // Initialize attendees list based on quantity
        const newAttendees = Array(ticketQuantity).fill(null).map(() => ({
            name: "", email: "", phone: "", idNumber: ""
        }));

        if (sameInfo && mainAttendee.name) {
            // Pre-fill if main attendee data exists
            newAttendees.forEach(a => {
                a.name = mainAttendee.name;
                a.email = mainAttendee.email;
                a.phone = mainAttendee.phone;
                a.idNumber = mainAttendee.idNumber;
            });
        }

        setAttendeesList(newAttendees);
        setStep(2);
    };

    const handleContinueToPayment = () => {
        // Validate attendees
        if (sameInfo) {
            if (!mainAttendee.name || !mainAttendee.email) {
                alert("Completa los datos del comprador principal");
                return;
            }
        } else {
            const isValid = attendeesList.every(a => a.name && a.email);
            if (!isValid) {
                alert("Completa los datos de todos los asistentes");
                return;
            }
        }
        setStep(3);
    };

    const handleCompleteSale = async () => {
        if (!selectedEvent || !selectedEvent.id || !user) return;
        setIsProcessing(true);

        try {
            const finalAttendees = sameInfo
                ? Array(ticketQuantity).fill(mainAttendee)
                : attendeesList;

            const processedAttendees = await Promise.all(finalAttendees.map(async (att, index) => {
                // Generate secure ID
                const uniqueSuffix = Math.random().toString(36).substring(2, 7).toUpperCase();
                const timestamp = Date.now().toString(36).toUpperCase();
                const baseTicketId = `POS-${timestamp}-${uniqueSuffix}`;

                const secureTicketId = await generateSecureTicketId(
                    baseTicketId,
                    att.email,
                    selectedEvent.id!
                );

                return {
                    id: Date.now() + index,
                    Name: att.name,
                    Email: att.email,
                    Phone: att.phone,
                    IdNumber: att.idNumber,
                    Zone: selectedZone,
                    Status: "Confirmado",
                    ticketId: secureTicketId,
                    purchaseDate: new Date().toISOString(),
                    paymentMethod: paymentMethod,
                    soldBy: user.email
                };
            }));

            // 1. Update Firestore
            const eventRef = doc(db, "events", selectedEvent.id);
            await updateDoc(eventRef, {
                "distribution.uploadedGuests": arrayUnion(...processedAttendees)
            });

            // 2. Send Emails
            // We'll send individually to ensure each gets their ticket
            // In a real bulk scenario, you might want a batch API
            for (const attendee of processedAttendees) {
                try {
                    await fetch('/api/send-ticket', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            email: attendee.Email,
                            attendeeName: attendee.Name,
                            eventName: selectedEvent.name,
                            eventDate: selectedEvent.date,
                            eventTime: selectedEvent.startTime,
                            eventLocation: selectedEvent.location,
                            ticketId: attendee.ticketId,
                            zone: attendee.Zone,
                            seat: "General" // POS usually doesn't handle seat selection in MVP
                        }),
                    });
                } catch (emailError) {
                    console.error("Error sending email to", attendee.Email, emailError);
                }
            }

            alert("¡Venta completada exitosamente! Los tickets han sido enviados.");

            // Reset
            setSelectedEvent(null);
            setStep(1);
            setTicketQuantity(1);
            setMainAttendee({ name: "", email: "", phone: "", idNumber: "" });
            setAttendeesList([]);

        } catch (error) {
            console.error("Error completing sale:", error);
            alert("Hubo un error al procesar la venta.");
        } finally {
            setIsProcessing(false);
        }
    };

    const selectedZonePrice = selectedEvent?.venue?.zones.find(z => z.name === selectedZone)?.price || 0;
    const total = selectedZonePrice * ticketQuantity;

    if (loading) return <div className="p-8 text-center">Cargando eventos...</div>;

    return (
        <div className="max-w-6xl mx-auto p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Punto de Venta (POS)</h1>
            <p className="text-gray-500 mb-8">Registra ventas manuales y envía tickets al instante.</p>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column: Event Selection & Config */}
                <div className="lg:col-span-2 space-y-6">

                    {/* Step 1: Event & Tickets */}
                    <div className={`bg-white rounded-xl border transition-all ${step === 1 ? 'border-indigo-600 shadow-md' : 'border-gray-200'}`}>
                        <div className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-lg font-bold text-gray-900 flex items-center">
                                    <span className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3 text-sm">1</span>
                                    Selección de Evento y Tickets
                                </h2>
                                {step > 1 && (
                                    <button onClick={() => setStep(1)} className="text-sm text-indigo-600 font-medium hover:underline">Editar</button>
                                )}
                            </div>

                            {step === 1 && (
                                <div className="space-y-6 pl-11">
                                    {/* Event Selector */}
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">Evento</label>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            {events.map(event => (
                                                <div
                                                    key={event.id}
                                                    onClick={() => handleEventSelect(event)}
                                                    className={`cursor-pointer p-4 rounded-lg border-2 transition-all ${selectedEvent?.id === event.id ? 'border-indigo-600 bg-indigo-50' : 'border-gray-200 hover:border-gray-300'}`}
                                                >
                                                    <h3 className="font-bold text-gray-900">{event.name}</h3>
                                                    <p className="text-sm text-gray-500 flex items-center mt-1">
                                                        <Calendar className="w-3 h-3 mr-1" /> {event.date}
                                                    </p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    {selectedEvent && (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-top-2">
                                            <div>
                                                <label className="block text-sm font-medium text-gray-700 mb-2">Zona / Localidad</label>
                                                <select
                                                    value={selectedZone}
                                                    onChange={(e) => setSelectedZone(e.target.value)}
                                                    className="w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                                >
                                                    {selectedEvent.venue?.zones.map(zone => (
                                                        <option key={zone.id} value={zone.name}>
                                                            {zone.name} - ${zone.price.toLocaleString()}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-gray-700 mb-2">Cantidad</label>
                                                <div className="flex items-center">
                                                    <button
                                                        onClick={() => setTicketQuantity(Math.max(1, ticketQuantity - 1))}
                                                        className="w-10 h-10 rounded-l-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50"
                                                    >-</button>
                                                    <input
                                                        type="number"
                                                        value={ticketQuantity}
                                                        readOnly
                                                        className="w-16 h-10 border-y border-gray-300 text-center focus:ring-0"
                                                    />
                                                    <button
                                                        onClick={() => setTicketQuantity(Math.min(10, ticketQuantity + 1))}
                                                        className="w-10 h-10 rounded-r-lg border border-gray-300 flex items-center justify-center hover:bg-gray-50"
                                                    >+</button>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {selectedEvent && (
                                        <div className="pt-4">
                                            <button
                                                onClick={handleContinueToAttendees}
                                                className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
                                            >
                                                Continuar
                                            </button>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Step 2: Attendees */}
                    <div className={`bg-white rounded-xl border transition-all ${step === 2 ? 'border-indigo-600 shadow-md' : 'border-gray-200'}`}>
                        <div className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-lg font-bold text-gray-900 flex items-center">
                                    <span className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 text-sm ${step >= 2 ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-400'}`}>2</span>
                                    Datos del Asistente
                                </h2>
                                {step > 2 && (
                                    <button onClick={() => setStep(2)} className="text-sm text-indigo-600 font-medium hover:underline">Editar</button>
                                )}
                            </div>

                            {step === 2 && (
                                <div className="space-y-6 pl-11">
                                    {ticketQuantity > 1 && (
                                        <div className="flex items-center space-x-4 mb-4">
                                            <label className="flex items-center cursor-pointer">
                                                <input
                                                    type="radio"
                                                    checked={sameInfo}
                                                    onChange={() => setSameInfo(true)}
                                                    className="text-indigo-600 focus:ring-indigo-500"
                                                />
                                                <span className="ml-2 text-sm text-gray-700">Usar mismos datos para todos</span>
                                            </label>
                                            <label className="flex items-center cursor-pointer">
                                                <input
                                                    type="radio"
                                                    checked={!sameInfo}
                                                    onChange={() => setSameInfo(false)}
                                                    className="text-indigo-600 focus:ring-indigo-500"
                                                />
                                                <span className="ml-2 text-sm text-gray-700">Datos individuales</span>
                                            </label>
                                        </div>
                                    )}

                                    {sameInfo ? (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div className="md:col-span-2">
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Nombre Completo</label>
                                                <div className="relative">
                                                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                    <input
                                                        type="text"
                                                        value={mainAttendee.name}
                                                        onChange={(e) => setMainAttendee({ ...mainAttendee, name: e.target.value })}
                                                        className="w-full pl-9 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                                        placeholder="Ej. Juan Pérez"
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Email (para enviar ticket)</label>
                                                <div className="relative">
                                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                    <input
                                                        type="email"
                                                        value={mainAttendee.email}
                                                        onChange={(e) => setMainAttendee({ ...mainAttendee, email: e.target.value })}
                                                        className="w-full pl-9 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                                        placeholder="juan@ejemplo.com"
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Teléfono</label>
                                                <div className="relative">
                                                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                    <input
                                                        type="tel"
                                                        value={mainAttendee.phone}
                                                        onChange={(e) => setMainAttendee({ ...mainAttendee, phone: e.target.value })}
                                                        className="w-full pl-9 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                                        placeholder="+57 300..."
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <label className="block text-xs font-medium text-gray-500 mb-1">Cédula / ID</label>
                                                <div className="relative">
                                                    <IdCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                    <input
                                                        type="text"
                                                        value={mainAttendee.idNumber}
                                                        onChange={(e) => setMainAttendee({ ...mainAttendee, idNumber: e.target.value })}
                                                        className="w-full pl-9 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                                                        placeholder="123456789"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="space-y-6">
                                            {attendeesList.map((att, idx) => (
                                                <div key={idx} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                                                    <h4 className="font-bold text-sm text-gray-700 mb-3">Asistente #{idx + 1}</h4>
                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                        <input
                                                            type="text"
                                                            placeholder="Nombre"
                                                            value={att.name}
                                                            onChange={(e) => {
                                                                const newList = [...attendeesList];
                                                                newList[idx].name = e.target.value;
                                                                setAttendeesList(newList);
                                                            }}
                                                            className="rounded-lg border-gray-300 text-sm"
                                                        />
                                                        <input
                                                            type="email"
                                                            placeholder="Email"
                                                            value={att.email}
                                                            onChange={(e) => {
                                                                const newList = [...attendeesList];
                                                                newList[idx].email = e.target.value;
                                                                setAttendeesList(newList);
                                                            }}
                                                            className="rounded-lg border-gray-300 text-sm"
                                                        />
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    <div className="pt-4">
                                        <button
                                            onClick={handleContinueToPayment}
                                            className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
                                        >
                                            Continuar al Pago
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Step 3: Payment */}
                    <div className={`bg-white rounded-xl border transition-all ${step === 3 ? 'border-indigo-600 shadow-md' : 'border-gray-200'}`}>
                        <div className="p-6">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-lg font-bold text-gray-900 flex items-center">
                                    <span className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 text-sm ${step >= 3 ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-400'}`}>3</span>
                                    Pago y Confirmación
                                </h2>
                            </div>

                            {step === 3 && (
                                <div className="space-y-6 pl-11">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-3">Método de Pago</label>
                                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                            {['Efectivo', 'Transferencia', 'Nequi', 'Daviplata', 'PSE', 'Tarjeta'].map(method => (
                                                <button
                                                    key={method}
                                                    onClick={() => setPaymentMethod(method)}
                                                    className={`p-3 rounded-lg border text-sm font-medium transition-all ${paymentMethod === method ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300 text-gray-600'}`}
                                                >
                                                    {method}
                                                </button>
                                            ))}
                                        </div>
                                    </div>

                                    <div className="bg-yellow-50 border border-yellow-100 rounded-lg p-4 text-sm text-yellow-800">
                                        <p className="font-bold flex items-center mb-1">
                                            <CheckCircle className="w-4 h-4 mr-2" />
                                            Confirmación de Venta
                                        </p>
                                        <p>Al confirmar, se registrará la venta en el sistema y se enviarán los tickets automáticamente a los correos registrados.</p>
                                    </div>

                                    <div className="pt-4">
                                        <button
                                            onClick={handleCompleteSale}
                                            disabled={isProcessing}
                                            className="w-full bg-green-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-green-700 transition-colors shadow-lg hover:shadow-xl flex items-center justify-center"
                                        >
                                            {isProcessing ? (
                                                <>
                                                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                                                    Procesando...
                                                </>
                                            ) : (
                                                <>
                                                    <CheckCircle className="w-5 h-5 mr-2" />
                                                    Completar Venta (${total.toLocaleString()})
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Right Column: Summary */}
                <div className="lg:col-span-1">
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 sticky top-6">
                        <h3 className="text-lg font-bold text-gray-900 mb-4">Resumen de Venta</h3>

                        {selectedEvent ? (
                            <div className="space-y-4">
                                <div className="pb-4 border-b border-gray-100">
                                    <p className="text-sm text-gray-500">Evento</p>
                                    <p className="font-bold text-gray-900">{selectedEvent.name}</p>
                                    <p className="text-xs text-gray-500">{selectedEvent.date}</p>
                                </div>

                                <div className="pb-4 border-b border-gray-100">
                                    <div className="flex justify-between text-sm mb-2">
                                        <span className="text-gray-600">Ticket ({selectedZone})</span>
                                        <span className="font-medium">${selectedZonePrice.toLocaleString()}</span>
                                    </div>
                                    <div className="flex justify-between text-sm mb-2">
                                        <span className="text-gray-600">Cantidad</span>
                                        <span className="font-medium">x {ticketQuantity}</span>
                                    </div>
                                </div>

                                <div className="flex justify-between items-center pt-2">
                                    <span className="text-lg font-bold text-gray-900">Total</span>
                                    <span className="text-2xl font-bold text-indigo-600">${total.toLocaleString()}</span>
                                </div>

                                {step === 3 && (
                                    <div className="pt-4 border-t border-gray-100">
                                        <p className="text-xs text-gray-500 mb-1">Método de Pago</p>
                                        <p className="font-medium text-gray-900 flex items-center">
                                            <CreditCard className="w-4 h-4 mr-2 text-gray-400" />
                                            {paymentMethod}
                                        </p>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="text-center py-8 text-gray-400">
                                <Ticket className="w-12 h-12 mx-auto mb-2 opacity-50" />
                                <p>Selecciona un evento para comenzar</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
