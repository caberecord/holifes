"use client";
import { useEventWizardStore } from "@/store/eventWizardStore";
import VenueDesigner from "../../VenueDesigner";

export default function Step3VenueDesign() {
    const { venue, setVenueType, updateZones, setStep } = useEventWizardStore();

    const handleVenueChange = (newVenue: any) => {
        if (newVenue.type !== venue.type) {
            setVenueType(newVenue.type);
        }
        if (newVenue.zones !== venue.zones) {
            updateZones(newVenue.zones);
        }
    };

    return (
        <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Diseño del Escenario</h2>
            <p className="text-gray-500 mb-8">Configura las zonas, su forma y distribución.</p>

            <VenueDesigner venue={venue} onChange={handleVenueChange} />

            <div className="flex justify-between pt-8 border-t border-gray-100 mt-8">
                <button
                    onClick={() => setStep(2)}
                    className="text-gray-600 px-6 py-2 rounded-lg hover:bg-gray-100 transition-colors font-medium"
                >
                    Atrás
                </button>
                <button
                    onClick={() => setStep(4)}
                    disabled={!venue.type || venue.zones.length === 0}
                    className={`px-6 py-2 rounded-lg transition-colors font-medium ${venue.type && venue.zones.length > 0
                        ? "bg-indigo-600 text-white hover:bg-indigo-700"
                        : "bg-gray-200 text-gray-400 cursor-not-allowed"
                        }`}
                >
                    Continuar
                </button>
            </div>
        </div>
    );
}
