"use client";
import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { collection, query, getDocs } from "firebase/firestore";
import { Event } from "@/types/event";
import { Line } from "react-chartjs-2";
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    Filler,
} from "chart.js";
import { ArrowUp, ArrowDown, Calendar as CalendarIcon, Filter } from "lucide-react";

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    Filler
);

const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: { display: false },
        tooltip: {
            mode: "index" as const,
            intersect: false,
            backgroundColor: "rgba(255, 255, 255, 0.95)",
            titleColor: "#1f2937",
            bodyColor: "#6b7280",
            borderColor: "#e5e7eb",
            borderWidth: 1,
        },
    },
    scales: {
        x: { grid: { display: false }, ticks: { color: "#9ca3af", font: { size: 12 } } },
        y: { grid: { color: "#f3f4f6" }, ticks: { color: "#9ca3af", font: { size: 12 }, callback: (value: any) => `$${value}` } },
    },
    interaction: { mode: "nearest" as const, axis: "x" as const, intersect: false },
};

export default function DashboardStats() {
    const [events, setEvents] = useState<Event[]>([]);
    const [loading, setLoading] = useState(true);
    const [dateFilter, setDateFilter] = useState<"week" | "month" | "quarter" | "year" | "custom">("month");
    const [customRange, setCustomRange] = useState({ start: "", end: "" });

    useEffect(() => {
        const fetchEvents = async () => {
            try {
                const q = query(collection(db, "events"));
                const querySnapshot = await getDocs(q);
                const eventsData = querySnapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                })) as Event[];
                setEvents(eventsData);
            } catch (error) {
                console.error("Error fetching events:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchEvents();
    }, []);

    // Filter Logic
    const getFilteredTransactions = () => {
        const now = new Date();
        let startDate = new Date();
        let endDate = new Date();

        if (dateFilter === "week") {
            const day = now.getDay();
            const diff = now.getDate() - day + (day === 0 ? -6 : 1); // Adjust when day is sunday
            startDate = new Date(now.setDate(diff));
            startDate.setHours(0, 0, 0, 0);
        } else if (dateFilter === "month") {
            startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        } else if (dateFilter === "quarter") {
            const quarter = Math.floor((now.getMonth() + 3) / 3);
            startDate = new Date(now.getFullYear(), (quarter - 1) * 3, 1);
        } else if (dateFilter === "year") {
            startDate = new Date(now.getFullYear(), 0, 1);
        } else if (dateFilter === "custom" && customRange.start) {
            startDate = new Date(customRange.start);
            if (customRange.end) endDate = new Date(customRange.end);
        }

        const transactions: any[] = [];

        events.forEach(event => {
            const attendees = event.distribution?.uploadedGuests || [];
            attendees.forEach(guest => {
                // Use event date as fallback
                const dateStr = event.createdAt || event.date;
                const txDate = new Date(dateStr);

                if (txDate >= startDate && txDate <= endDate) {
                    const zone = event.venue?.zones.find(z => z.name === guest.Zone);
                    const price = zone?.price || 0;
                    if (price > 0 || guest.ticketId) {
                        transactions.push({
                            ...guest,
                            price,
                            eventName: event.name,
                            date: txDate
                        });
                    }
                }
            });
        });

        return transactions.sort((a, b) => b.date.getTime() - a.date.getTime());
    };

    const transactions = getFilteredTransactions();

    // Metrics Calculation
    const totalRevenue = transactions.reduce((acc, tx) => acc + (tx.price || 0), 0);
    const ticketsSold = transactions.length;
    const activeEventsCount = events.filter(e => e.status === 'published').length; // Or check date

    // Chart Data Preparation
    const getChartData = () => {
        const labels: string[] = [];
        const dataPoints: number[] = [];

        // Group by day/month depending on filter
        const groupedData: Record<string, number> = {};

        transactions.forEach(tx => {
            const dateKey = tx.date.toLocaleDateString('es-ES', {
                day: 'numeric',
                month: 'short'
            });
            groupedData[dateKey] = (groupedData[dateKey] || 0) + (tx.price || 0);
        });

        // Sort keys chronologically (rough approximation for simplicity)
        Object.keys(groupedData).reverse().forEach(key => {
            labels.push(key);
            dataPoints.push(groupedData[key]);
        });

        // If empty, show placeholders
        if (labels.length === 0) {
            return {
                labels: ["Sin datos"],
                datasets: [{
                    label: "Ingresos",
                    data: [0],
                    borderColor: "rgb(99, 102, 241)",
                    backgroundColor: "rgba(99, 102, 241, 0.05)",
                    tension: 0.4,
                    fill: true,
                }]
            };
        }

        return {
            labels,
            datasets: [
                {
                    fill: true,
                    label: "Ingresos",
                    data: dataPoints,
                    borderColor: "rgb(99, 102, 241)",
                    backgroundColor: "rgba(99, 102, 241, 0.05)",
                    tension: 0.4,
                    borderWidth: 2,
                },
            ],
        };
    };

    if (loading) return <div className="p-8 text-center">Cargando tablero...</div>;

    return (
        <div className="space-y-6">
            {/* Header & Filters */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-xl font-bold text-gray-900">Resumen General</h2>
                <div className="flex items-center gap-2 bg-white p-1 rounded-lg border border-gray-200 shadow-sm">
                    <select
                        value={dateFilter}
                        onChange={(e) => setDateFilter(e.target.value as any)}
                        className="border-0 bg-transparent text-sm font-medium text-gray-700 focus:ring-0 cursor-pointer"
                    >
                        <option value="week">Esta Semana</option>
                        <option value="month">Este Mes</option>
                        <option value="quarter">Este Trimestre</option>
                        <option value="year">Este Año</option>
                        <option value="custom">Personalizado</option>
                    </select>
                    {dateFilter === "custom" && (
                        <div className="flex items-center gap-2 px-2 border-l border-gray-200">
                            <input
                                type="date"
                                value={customRange.start}
                                onChange={(e) => setCustomRange({ ...customRange, start: e.target.value })}
                                className="text-xs border-gray-300 rounded p-1"
                            />
                            <span className="text-gray-400">-</span>
                            <input
                                type="date"
                                value={customRange.end}
                                onChange={(e) => setCustomRange({ ...customRange, end: e.target.value })}
                                className="text-xs border-gray-300 rounded p-1"
                            />
                        </div>
                    )}
                </div>
            </div>

            {/* Metric Cards */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                {[
                    { title: "Ingresos Totales", value: `$${totalRevenue.toLocaleString()}`, icon: "💰", color: "bg-emerald-50 text-emerald-600" },
                    { title: "Entradas Vendidas", value: ticketsSold, icon: "🎟️", color: "bg-blue-50 text-blue-600" },
                    { title: "Eventos Activos", value: activeEventsCount, icon: "📅", color: "bg-purple-50 text-purple-600" },
                    { title: "Promedio Ticket", value: `$${ticketsSold > 0 ? Math.round(totalRevenue / ticketsSold).toLocaleString() : 0}`, icon: "📈", color: "bg-orange-50 text-orange-600" },
                ].map((metric, index) => (
                    <div key={index} className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-all duration-200">
                        <div className="flex items-start justify-between mb-3">
                            <div className={`rounded-lg p-3 text-2xl ${metric.color}`}>{metric.icon}</div>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500 mb-1">{metric.title}</p>
                            <h3 className="text-2xl font-bold text-gray-900">{metric.value}</h3>
                        </div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                {/* Chart Section */}
                <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm lg:col-span-2">
                    <div className="mb-6">
                        <h3 className="text-lg font-bold text-gray-900">Rendimiento de Ventas</h3>
                        <p className="text-sm text-gray-500">Ingresos en el periodo seleccionado</p>
                    </div>
                    <div className="h-80 w-full">
                        <Line options={chartOptions} data={getChartData()} />
                    </div>
                </div>

                {/* Recent Activity Section */}
                <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm overflow-hidden">
                    <h3 className="mb-5 text-lg font-bold text-gray-900">Actividad Reciente</h3>
                    <div className="space-y-4 max-h-[350px] overflow-y-auto pr-2">
                        {transactions.length > 0 ? (
                            transactions.slice(0, 6).map((tx, i) => (
                                <div key={i} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                                    <div className="flex items-center gap-3">
                                        <div className="h-9 w-9 rounded-full bg-indigo-100 flex items-center justify-center text-sm font-bold text-indigo-600 shrink-0">
                                            {tx.Name?.charAt(0) || "U"}
                                        </div>
                                        <div className="min-w-0">
                                            <p className="text-sm font-medium text-gray-900 truncate">
                                                {tx.Name || "Usuario"} <span className="text-gray-400 font-normal">compró entrada</span>
                                            </p>
                                            <p className="text-xs text-gray-500 truncate">{tx.eventName}</p>
                                        </div>
                                    </div>
                                    <span className="text-sm font-semibold text-emerald-600 shrink-0">+${tx.price?.toLocaleString()}</span>
                                </div>
                            ))
                        ) : (
                            <p className="text-center text-gray-400 py-8">No hay actividad en este periodo</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
