import POSModule from "@/components/Dashboard/Sales/POSModule";

export default function SalesPage() {
    return <POSModule />;
}
