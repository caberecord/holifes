import DashboardStats from "@/components/Dashboard/DashboardStats";

export default function DashboardPage() {
    return <DashboardStats />;
}
